﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColorBase : MonoBehaviour {

    protected virtual void RegisterWithController()
    {

    }
    public virtual void Unify()
    {

    }
}
