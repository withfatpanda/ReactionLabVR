Thank you for purchasing Potions with Liquid Simulation via the Unity Asset Store.

Please read the PDF documentation provided for set up instructions, details regarding script functionality and best use guides, as well as FAQ and 
version changes. 

Demonstration and tutorial video content is available via our Youtube channel www.youtube.com/channel/UC2T7YzK-hq2gvIWJlIKfwug

If you require additional support please send us and email to contact@2ginge.com

V1.0 - June 2017
V1.1 - July 2017
V1.2 - October 2017
V2.0 - November 2017
V3.0 - July 2018


� 2Ginge 2017-2018